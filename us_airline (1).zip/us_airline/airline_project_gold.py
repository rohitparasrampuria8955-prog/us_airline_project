# Databricks notebook source
# MAGIC %sql
# MAGIC select * from airline.gold.airport_gold

# COMMAND ----------

# DBTITLE 1,Cell 2
display(spark.sql("DESCRIBE TABLE airline.gold.airport_gold"))

# COMMAND ----------

df = spark.read.table("airline.gold.airport_gold")
display(df)

# COMMAND ----------

sfOptions = {
    "host": "FIJAMVO-IR52717.snowflakecomputing.com",
    "port": "443",
    "sfUser": "ROHITMITTAL",
    "sfPassword": "Rohit@8955@2004",
    "sfDatabase": "airline",
    "sfSchema": "gold",
    "sfWarehouse": "COMPUTE_WH",
    "sfRole": "ORGADMIN"
}


# COMMAND ----------

df.write \
    .format("snowflake") \
    .options(**sfOptions) \
    .option("dbtable", "airline.gold.FLIGHT_ANALYTICS") \
    .mode("append") \
    .save()