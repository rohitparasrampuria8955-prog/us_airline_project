# Databricks notebook source
# MAGIC
# MAGIC %sql
# MAGIC CREATE  EXTERNAL LOCATION IF NOT EXISTS airline_LOCATION
# MAGIC URL 's3://us-airline-project-20-08/'
# MAGIC WITH (STORAGE CREDENTIAL airline_project);

# COMMAND ----------

# MAGIC %sql
# MAGIC create  catalog if not exists airline
# MAGIC managed location 's3://us-airline-project-20-08/process_data/'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS airline.landing
# MAGIC COMMENT 'This schema hold production data'
# MAGIC MANAGED LOCATION 's3://us-airline-project-20-08/';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS airline.bronze
# MAGIC COMMENT 'This schema hold production data'
# MAGIC MANAGED LOCATION 's3://us-airline-project-20-08/process_data/bronze';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS airline.silver
# MAGIC COMMENT 'This schema hold production data'
# MAGIC MANAGED LOCATION 's3://us-airline-project-20-08/process_data/silver';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS airline.gold
# MAGIC COMMENT 'This schema hold production data'
# MAGIC MANAGED LOCATION 's3://us-airline-project-20-08/process_data/gold';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL VOLUME IF NOT EXISTS airline.landing.airline_volume1
# MAGIC LOCATION 's3://us-airline-project-20-08/landing/';

# COMMAND ----------

df = spark.read \
    .format("csv") \
    .option("mode", "PERMISSIVE") \
    .option("header", "true") \
    .load("/Volumes/airline/landing/airline_volume1/airline_data/2025/")

display(df)

# COMMAND ----------

display(df.groupBy("Month").count().orderBy("Month"))

# COMMAND ----------



# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

# %python 
# import pyspark.sql.functions as F

# total_rows = df.count()

# for col_name in df.columns:
#     null_percentage = (
#         df.filter(F.col(col_name).isNull()).count()
#         / total_rows
#     ) * 100

#     print(f"{col_name}: {null_percentage:.2f}%")

# COMMAND ----------

df = df.withColumn(
    "arrival_delay",
    F.when(F.col("ArrDelay").isNull(), 1)
     .otherwise(0)
)

# COMMAND ----------

df.select(
    F.min("FlightDate").alias("starting_flight_date"),
    F.max("FlightDate").alias("last_flight_date")
).show()

# COMMAND ----------

# Flight Date DQ
df=df.withColumn(
        "flight_date_dq",
        F.when(F.col("FlightDate").isNull(), 1).otherwise(0)
    )

# COMMAND ----------

# Reporting Airline DQ
df=  df.withColumn("reporting_airline_dq",
        F.when(
            F.col("Reporting_Airline").isNull(),
            1
        ).otherwise(0)
    )

# COMMAND ----------

# Destination DQ
df=  df.withColumn(
        "destination_dq",
        F.when(
            F.col("Dest").isNull(),
            1
        ).otherwise(0)
    )

# COMMAND ----------

# Origin DQ
df = df.withColumn(
        "origin_dq",
        F.when(
            F.col("Origin").isNull(),
            1
        ).otherwise(0)
    )

# COMMAND ----------

# Destination DQ
df= df.withColumn(
        "destination_dq",
        F.when(
            F.col("Dest").isNull(),1 ).otherwise(0))

# COMMAND ----------

 # Arrival Delay DQ

df = df.withColumn(
    "ArrDelay",
    F.col("ArrDelay").cast("double")
)

df = df.withColumn(
    "arrival_delay_dq",
    F.when(
        F.col("ArrDelay").isNull() |
        (F.col("ArrDelay") < -120) |
        (F.col("ArrDelay") > 840),
        1
    ).otherwise(0)
)

# COMMAND ----------


    # Same Origin and Destination
df=df.withColumn("similar_route_dq",F.when( F.col("Origin").isNull() | F.col("Dest").isNull() |
            (F.col("Origin") == F.col("Dest")),
            1
        ).otherwise(0)
    )

# COMMAND ----------

df = df.withColumn(
    "Distance",
    F.col("Distance").cast("double")
)
df = df.withColumn("distance_dq",
        F.when(
            F.col("Distance").isNull() |
            (F.col("Distance") > 16000),
            1
        ).otherwise(0)
    )

# COMMAND ----------

dq_columns = [
    "flight_date_dq",
    "reporting_airline_dq",
    "origin_dq",
    "destination_dq",
    "arrival_delay_dq",
    "similar_route_dq",
    "distance_dq"
]

df = df.withColumn(
    "total_flag",
    sum(F.col(c) for c in dq_columns)
)

# COMMAND ----------

df = df.withColumn(
    "cleaned",
    F.when(F.col("total_flag") == 0, 1).otherwise(0)
)

# COMMAND ----------

df.write.mode("Append").partitionBy("Year","Month").saveAsTable("airline.bronze.airline_bronze")

# COMMAND ----------

df1 = spark.read \
    .option("multiline", "true") \
    .option("mode", "PERMISSIVE") \
    .json("/Volumes/airline/landing/airline_volume1/airport_data/")

display(df1)

# COMMAND ----------

from pyspark.sql.functions import col
filtered_df = df1.filter(
    (col("country") == "United States") &
    (col("latitude").cast("double").between(-90, 90)) &
    (col("longitude").cast("double").between(-80, 80))
)

display(filtered_df)



# COMMAND ----------

filtered_df.write.format("delta").mode("Append").saveAsTable("airline.bronze.airport_bronze")