# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT
# MAGIC     FlightDate,
# MAGIC     Flight_Number_Reporting_Airline,
# MAGIC     Origin,
# MAGIC     Dest,
# MAGIC     COUNT(*) AS cnt
# MAGIC FROM airline.bronze.airline_bronze
# MAGIC GROUP BY
# MAGIC     FlightDate,
# MAGIC     Flight_Number_Reporting_Airline,
# MAGIC     Origin,
# MAGIC     Dest
# MAGIC HAVING COUNT(*) > 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE airline.silver.airline_silver AS
# MAGIC
# MAGIC WITH assigen_row_no AS (
# MAGIC     SELECT
# MAGIC         *,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             ORDER BY
# MAGIC                 FlightDate,
# MAGIC                 Reporting_Airline,
# MAGIC                 Flight_Number_Reporting_Airline,
# MAGIC                 Origin,
# MAGIC                 Dest,
# MAGIC                 CRSDepTime
# MAGIC         ) AS row_no
# MAGIC     FROM airline.bronze.airline_bronze
# MAGIC ),
# MAGIC
# MAGIC duplicate_remove AS (
# MAGIC     SELECT
# MAGIC         a.*
# MAGIC     FROM assigen_row_no a
# MAGIC     LEFT JOIN assigen_row_no b
# MAGIC         ON  a.FlightDate = b.FlightDate
# MAGIC         AND a.Reporting_Airline = b.Reporting_Airline
# MAGIC         AND a.Flight_Number_Reporting_Airline = b.Flight_Number_Reporting_Airline
# MAGIC         AND a.Origin = b.Origin
# MAGIC         AND a.Dest = b.Dest
# MAGIC         AND a.CRSDepTime = b.CRSDepTime
# MAGIC         AND a.row_no > b.row_no
# MAGIC
# MAGIC     WHERE b.row_no IS NULL
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM duplicate_remove
# MAGIC WHERE cleaned = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table airline.silver.airline_silver
# MAGIC set tblproperties(
# MAGIC     'delta.columnMapping.mode' = 'name'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE airline.silver.airline_silver
# MAGIC DROP COLUMNS (
# MAGIC     arrival_delay,
# MAGIC     flight_date_dq,
# MAGIC     reporting_airline_dq,
# MAGIC     destination_dq,
# MAGIC     origin_dq,
# MAGIC     arrival_delay_dq,
# MAGIC     similar_route_dq,
# MAGIC     distance_dq
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select *, CRSDepTime/100 as dep_hour, CRSArrTime%100 as arr_hour from airline.silver.airline_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table airline.silver.airline_silver as
# MAGIC SELECT
# MAGIC     *,
# MAGIC     
# MAGIC     CONCAT(
# MAGIC         LPAD(FLOOR(CRSDepTime / 100), 2, '0'),
# MAGIC         ':',
# MAGIC         LPAD(CRSDepTime % 100, 2, '0')
# MAGIC     ) AS crs_dep_time_std,
# MAGIC
# MAGIC     CONCAT(
# MAGIC         LPAD(FLOOR(CRSArrTime / 100), 2, '0'),
# MAGIC         ':',
# MAGIC         LPAD(CRSArrTime % 100, 2, '0')
# MAGIC     ) AS crs_arr_time_std
# MAGIC
# MAGIC FROM airline.silver.airline_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace table airline.silver.airline_silver as
# MAGIC select *, 
# MAGIC         floor(CRSDepTime/100)*60+(CRSDepTime%100) as CRSDepTime_minuts,
# MAGIC         floor(CRSArrTime/100)*60+(CRSArrTime%100) as CRSArrTime_minuts
# MAGIC from airline.silver.airline_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table airline .silver.airline_silver as
# MAGIC SELECT
# MAGIC     *,
# MAGIC     CASE
# MAGIC         WHEN try_cast(Cancelled AS DOUBLE) = 1 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS is_cancelled,
# MAGIC     CASE
# MAGIC         WHEN try_cast(Diverted AS DOUBLE) = 1 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS is_diverted,
# MAGIC     CASE
# MAGIC         WHEN try_cast(DepDel15 AS DOUBLE) = 1 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS is_departure_delayed,
# MAGIC     CASE
# MAGIC         WHEN try_cast(ArrivalDelayGroups AS DOUBLE) > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS is_arrival_delayed
# MAGIC FROM airline.silver.airline_silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table airline.silver.airline_silver as
# MAGIC select *,
# MAGIC     CASE
# MAGIC         WHEN is_cancelled = 'true' THEN 'Cancelled'
# MAGIC         WHEN cast(ArrDelayMinutes AS double) < 0 THEN 'Early'
# MAGIC         WHEN CAST(ArrDelayMinutes AS double) BETWEEN 0 AND 14
# MAGIC             THEN 'On Time'
# MAGIC         WHEN CAST(ArrDelayMinutes AS double) BETWEEN 15 AND 44
# MAGIC             THEN 'Minor Delay'
# MAGIC         WHEN CAST(ArrDelayMinutes AS double) BETWEEN 45 AND 120
# MAGIC             THEN 'Major Delay'
# MAGIC         WHEN CAST(ArrDelayMinutes AS double) > 120
# MAGIC             THEN 'Severe Delay'
# MAGIC         ELSE 'other_region'
# MAGIC     END AS arrival_catagory
# MAGIC from airline.silver.airline_silver;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from airline.bronze.airport_bronze

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from airline.silver.airline_silver

# COMMAND ----------

airport_df = spark.table("airline.bronze.airport_bronze")

# COMMAND ----------

print(airport_df.count())

# COMMAND ----------

flight_df = spark.table("airline.silver.airline_silver")

# COMMAND ----------

print(flight_df.count())

# COMMAND ----------

from pyspark.sql.functions import col, broadcast

origin_airport = airport_df.select(
    col("iata").alias("origin_iata"),
    col("latitude").alias("origin_latitude"),
    col("longitude").alias("origin_longitude")
)

destination_airport = airport_df.select(
    col("iata").alias("destination_iata"),
    col("latitude").alias("destination_latitude"),
    col("longitude").alias("destination_longitude")
)

# COMMAND ----------

from pyspark.sql.functions import col, when, broadcast
# Origin + Destination join
df_silver_joined_airports = (
    flight_df

    # Origin Airport Join
    .join(
        broadcast(origin_airport),
        col("Origin") == col("origin_iata"),
        "left"
    )
    .withColumn(
        "origin_airport_dataquality",
        when(col("origin_iata").isNull(), 1).otherwise(0)
    )

    # Destination Airport Join
    .join(
        broadcast(destination_airport),
        col("Dest") == col("destination_iata"),
        "left"
    )
    .withColumn(
        "destination_airport_dataquality",
        when(col("destination_iata").isNull(), 1).otherwise(0)
    )
)

display(df_silver_joined_airports)

# COMMAND ----------

from pyspark.sql.functions import radians, sin, cos, sqrt, asin

df_final = df_silver_joined_airports.withColumn(
    "calculeted_distance",
    6371 * 2 * asin(
        sqrt(
            sin(
                (
                    radians(col("destination_latitude").cast("double"))
                    - radians(col("origin_latitude").cast("double"))
                ) / 2
            ) ** 2
            +
            cos(radians(col("origin_latitude").cast("double"))) *
            cos(radians(col("destination_latitude").cast("double"))) *
            sin(
                (
                    radians(col("destination_longitude").cast("double"))
                    - radians(col("origin_longitude").cast("double"))
                ) / 2
            ) ** 2
        )
    )
)

display(df_final)

# COMMAND ----------

from pyspark.sql.functions import abs, round

df_final = df_final.withColumn(
    "distance_difference_percentage",
    round(
        abs(
            col("Distance").cast("double") -
            col("calculeted_distance")
        )
        / col("Distance").cast("double") * 100,
        2
    )
)

display(df_final)

# COMMAND ----------

df_final.write.format("delta").mode("Append").option("overwriteSchema", "true").partitionBy("Year","Month").saveAsTable("airline.gold.airport_gold")